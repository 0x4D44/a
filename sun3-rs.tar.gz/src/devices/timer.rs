//! Intersil 7170 deterministic hundredth-second timer.

const REG_INT: u32 = 0x10;
const REG_CMD: u32 = 0x11;
const INT_PENDING: u8 = 0x80;
const INT_HSEC: u8 = 0x02;
const CMD_INT_ENABLE: u8 = 0x10;
const CMD_RUN: u8 = 0x08;
const CYCLES_PER_HUNDREDTH_AT_20MHZ: u64 = 200_000;

#[derive(Debug, Clone, Default)]
pub struct Intersil7170 {
    int_status: u8,
    int_mask: u8,
    command: u8,
    phase_cycles: u64,
}

impl Intersil7170 {
    pub fn reset(&mut self) {
        *self = Self::default();
    }

    pub fn irq(&self) -> bool {
        self.command & CMD_INT_ENABLE != 0 && self.int_status & self.int_mask & !INT_PENDING != 0
    }

    pub fn advance(&mut self, cycles: u64) {
        if self.command & CMD_RUN == 0 || self.int_mask & INT_HSEC == 0 {
            return;
        }
        self.phase_cycles = self.phase_cycles.saturating_add(cycles);
        while self.phase_cycles >= CYCLES_PER_HUNDREDTH_AT_20MHZ {
            self.phase_cycles -= CYCLES_PER_HUNDREDTH_AT_20MHZ;
            self.int_status |= INT_HSEC;
        }
        self.update_pending();
    }

    fn update_pending(&mut self) {
        if self.command & CMD_INT_ENABLE != 0 && self.int_status & self.int_mask & !INT_PENDING != 0 {
            self.int_status |= INT_PENDING;
        } else {
            self.int_status &= !INT_PENDING;
        }
    }

    pub fn read(&mut self, offset: u32) -> u8 {
        match offset & 0x1fff {
            REG_INT => {
                let value = self.int_status;
                self.int_status = 0;
                self.update_pending();
                value
            }
            REG_CMD => self.command,
            _ => 0,
        }
    }

    pub fn write(&mut self, offset: u32, value: u8) {
        match offset & 0x1fff {
            REG_INT => {
                self.int_mask = value & !INT_PENDING;
                self.update_pending();
            }
            REG_CMD => {
                self.command = value;
                if self.command & CMD_RUN == 0 {
                    self.phase_cycles = 0;
                }
                self.update_pending();
            }
            _ => {}
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn periodic_interrupt_is_virtual_time_driven_and_read_to_clear() {
        let mut timer = Intersil7170::default();
        timer.write(REG_INT, INT_HSEC);
        timer.write(REG_CMD, CMD_RUN | CMD_INT_ENABLE);
        timer.advance(CYCLES_PER_HUNDREDTH_AT_20MHZ - 1);
        assert!(!timer.irq());
        timer.advance(1);
        assert!(timer.irq());
        assert_eq!(timer.read(REG_INT) & (INT_PENDING | INT_HSEC), INT_PENDING | INT_HSEC);
        assert!(!timer.irq());
    }
}
