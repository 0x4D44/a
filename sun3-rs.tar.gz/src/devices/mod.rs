//! Sun 3/60 onboard devices used during PROM execution.

pub mod lance;
pub mod scc;
pub mod timer;

pub use lance::Lance;
pub use scc::Scc;
pub use timer::Intersil7170;
