//! Minimal Am7990/LANCE register model used by the PROM's presence probes.
//!
//! Descriptor-ring DMA is deliberately kept as a separable next layer; the
//! register interface, reset state, RAP selection, CSR0 control and IRQ latch
//! are real rather than an all-zero probe stub.

const CSR0_INIT: u16 = 0x0001;
const CSR0_START: u16 = 0x0002;
const CSR0_STOP: u16 = 0x0004;
const CSR0_TDMD: u16 = 0x0008;
const CSR0_IENA: u16 = 0x0040;
const CSR0_IDON: u16 = 0x0100;
const CSR0_TINT: u16 = 0x0200;
const CSR0_RINT: u16 = 0x0400;
const CSR0_MERR: u16 = 0x0800;
const CSR0_MISS: u16 = 0x1000;
const CSR0_CERR: u16 = 0x2000;
const CSR0_BABL: u16 = 0x4000;
const CSR0_ERR: u16 = 0x8000;
const CSR0_CLEARABLE: u16 = CSR0_IDON | CSR0_TINT | CSR0_RINT | CSR0_MERR | CSR0_MISS | CSR0_CERR | CSR0_BABL;

#[derive(Debug, Clone)]
pub struct Lance {
    rap: u16,
    csr: [u16; 128],
}

impl Default for Lance {
    fn default() -> Self {
        let mut value = Self { rap: 0, csr: [0; 128] };
        value.reset();
        value
    }
}

impl Lance {
    pub fn reset(&mut self) {
        self.rap = 0;
        self.csr.fill(0);
        self.csr[0] = CSR0_STOP;
        self.csr[3] = 0;
    }

    pub fn irq(&self) -> bool {
        let csr0 = self.csr[0];
        csr0 & CSR0_IENA != 0 && csr0 & (CSR0_IDON | CSR0_TINT | CSR0_RINT | CSR0_MERR | CSR0_MISS | CSR0_CERR | CSR0_BABL) != 0
    }

    pub fn read_word(&mut self, offset: u32) -> u16 {
        match offset & 0x7 {
            0 | 1 => self.csr[self.rap as usize & 0x7f],
            2 | 3 => self.rap,
            4 | 5 => {
                self.reset();
                0
            }
            _ => 0,
        }
    }

    pub fn write_word(&mut self, offset: u32, value: u16) {
        match offset & 0x7 {
            0 | 1 => {
                let register = self.rap as usize & 0x7f;
                if register == 0 {
                    let old = self.csr[0];
                    let mut next = old & !(value & CSR0_CLEARABLE);
                    if value & CSR0_STOP != 0 {
                        next = CSR0_STOP;
                    }
                    if value & CSR0_INIT != 0 {
                        // The PROM only needs a deterministic completed init.
                        next &= !CSR0_STOP;
                        next |= CSR0_IDON;
                    }
                    if value & CSR0_START != 0 {
                        next &= !CSR0_STOP;
                        next |= CSR0_START;
                    }
                    if value & CSR0_TDMD != 0 {
                        next |= CSR0_TDMD;
                    }
                    next = (next & !CSR0_IENA) | (value & CSR0_IENA);
                    if next & (CSR0_MERR | CSR0_MISS | CSR0_CERR | CSR0_BABL) != 0 {
                        next |= CSR0_ERR;
                    } else {
                        next &= !CSR0_ERR;
                    }
                    self.csr[0] = next;
                } else {
                    self.csr[register] = value;
                }
            }
            2 | 3 => self.rap = value & 0x7f,
            4 | 5 => self.reset(),
            _ => {}
        }
    }

    pub fn read_byte(&mut self, offset: u32) -> u8 {
        let word = self.read_word(offset & !1);
        if offset & 1 == 0 { (word >> 8) as u8 } else { word as u8 }
    }

    pub fn write_byte(&mut self, offset: u32, value: u8) {
        let aligned = offset & !1;
        let old = self.read_word(aligned);
        let new = if offset & 1 == 0 {
            (old & 0x00ff) | ((value as u16) << 8)
        } else {
            (old & 0xff00) | value as u16
        };
        self.write_word(aligned, new);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rap_selects_csr_and_reset_returns_stopped_state() {
        let mut lance = Lance::default();
        assert_eq!(lance.read_word(0), CSR0_STOP);
        lance.write_word(2, 3);
        lance.write_word(0, 0x1234);
        assert_eq!(lance.read_word(0), 0x1234);
        lance.read_word(4);
        assert_eq!(lance.read_word(0), CSR0_STOP);
    }
}
