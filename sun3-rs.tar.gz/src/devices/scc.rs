//! Zilog Z8530 SCC model for serial, keyboard and mouse channels.

use std::collections::VecDeque;

const SERIAL_CTRL: u32 = 0;
const SERIAL_DATA: u32 = 1;

const W_CMD: usize = 0;
const CMD_PTR_MASK: u8 = 0x07;
const CMD_CMD_MASK: u8 = 0x38;
const CMD_HI: u8 = 0x08;
const CMD_CLR_TXINT: u8 = 0x28;
const CMD_CLR_IUS: u8 = 0x38;
const W_INTR: usize = 1;
const INTR_TXINT: u8 = 0x02;
const INTR_RXMODE_MASK: u8 = 0x18;
const INTR_RX_FIRST: u8 = 0x08;
const INTR_RX_ALL: u8 = 0x10;
const W_RXCTRL: usize = 3;
const RX_ENABLE: u8 = 0x01;
const W_TXCTRL2: usize = 5;
const TX_ENABLE: u8 = 0x08;
const W_MINTR: usize = 9;
const MINTR_RESET_MASK: u8 = 0xc0;
const MINTR_RESET_B: u8 = 0x40;
const MINTR_RESET_A: u8 = 0x80;
const MINTR_RESET_ALL: u8 = 0xc0;
const W_MISC2: usize = 14;
const MISC2_LOCAL_LOOP: u8 = 0x10;

const R_STATUS: usize = 0;
const STATUS_RX_AVAILABLE: u8 = 0x01;
const STATUS_TX_EMPTY: u8 = 0x04;
const STATUS_DCD: u8 = 0x08;
const STATUS_SYNC: u8 = 0x10;
const STATUS_CTS: u8 = 0x20;
const STATUS_TX_UNDERRUN: u8 = 0x40;
const R_SPEC: usize = 1;
const SPEC_ALL_SENT: u8 = 0x01;
const SPEC_BITS8: u8 = 0x06;

#[derive(Debug, Clone)]
struct Channel {
    selected: u8,
    write: [u8; 16],
    read: [u8; 16],
    rx: VecDeque<u8>,
    tx_irq: bool,
    rx_irq: bool,
}

impl Default for Channel {
    fn default() -> Self {
        let mut value = Self {
            selected: 0,
            write: [0; 16],
            read: [0; 16],
            rx: VecDeque::new(),
            tx_irq: false,
            rx_irq: false,
        };
        value.hard_reset();
        value
    }
}

impl Channel {
    fn hard_reset(&mut self) {
        self.selected = 0;
        self.write.fill(0);
        self.read.fill(0);
        self.rx.clear();
        self.tx_irq = false;
        self.rx_irq = false;
        // The diagnostic serial wiring presents modem signals asserted.
        self.read[R_STATUS] = STATUS_TX_EMPTY | STATUS_TX_UNDERRUN | STATUS_DCD | STATUS_SYNC | STATUS_CTS;
        self.read[R_SPEC] = SPEC_ALL_SENT | SPEC_BITS8;
    }

    fn refresh_rx_status(&mut self) {
        if self.rx.is_empty() {
            self.read[R_STATUS] &= !STATUS_RX_AVAILABLE;
            self.rx_irq = false;
        } else {
            self.read[R_STATUS] |= STATUS_RX_AVAILABLE;
            let mode = self.write[W_INTR] & INTR_RXMODE_MASK;
            self.rx_irq = self.write[W_RXCTRL] & RX_ENABLE != 0 && (mode == INTR_RX_FIRST || mode == INTR_RX_ALL);
        }
    }

    fn irq(&self) -> bool {
        (self.tx_irq && self.write[W_INTR] & INTR_TXINT != 0) || self.rx_irq
    }
}

/// Two-channel SCC. `channel 0` is B and `channel 1` is A, matching hardware.
#[derive(Debug, Clone, Default)]
pub struct Scc {
    channels: [Channel; 2],
    output: Vec<u8>,
}

impl Scc {
    pub fn reset(&mut self) {
        for channel in &mut self.channels {
            channel.hard_reset();
        }
        self.output.clear();
    }

    pub fn irq(&self) -> bool {
        self.channels.iter().any(Channel::irq)
    }

    fn decode(offset: u32) -> (usize, u32) {
        // Sun 3/60 wiring: A/B select on A2, control/data on A1.
        (((offset >> 2) & 1) as usize, (offset >> 1) & 1)
    }

    pub fn read(&mut self, offset: u32) -> u8 {
        let (channel_index, register_kind) = Self::decode(offset);
        let channel = &mut self.channels[channel_index];
        match register_kind {
            SERIAL_CTRL => {
                let value = channel.read[channel.selected as usize & 15];
                channel.selected = 0;
                value
            }
            SERIAL_DATA => {
                let value = channel.rx.pop_front().unwrap_or(0);
                channel.refresh_rx_status();
                value
            }
            _ => 0,
        }
    }

    pub fn write(&mut self, offset: u32, value: u8) {
        let (channel_index, register_kind) = Self::decode(offset);
        match register_kind {
            SERIAL_CTRL => self.write_control(channel_index, value),
            SERIAL_DATA => self.write_data(channel_index, value),
            _ => {}
        }
    }

    fn write_control(&mut self, channel_index: usize, value: u8) {
        let selected = self.channels[channel_index].selected as usize;
        if selected == W_CMD {
            let mut next = value & CMD_PTR_MASK;
            let command = value & CMD_CMD_MASK;
            match command {
                CMD_HI => next |= 8,
                CMD_CLR_TXINT => self.channels[channel_index].tx_irq = false,
                CMD_CLR_IUS => {
                    self.channels[channel_index].tx_irq = false;
                    self.channels[channel_index].rx_irq = false;
                }
                _ => {}
            }
            self.channels[channel_index].selected = next;
            return;
        }

        if selected == W_MINTR {
            match value & MINTR_RESET_MASK {
                MINTR_RESET_B => self.channels[0].hard_reset(),
                MINTR_RESET_A => self.channels[1].hard_reset(),
                MINTR_RESET_ALL => {
                    self.channels[0].hard_reset();
                    self.channels[1].hard_reset();
                }
                _ => self.channels[channel_index].write[selected] = value,
            }
        } else {
            self.channels[channel_index].write[selected] = value;
            if selected == W_RXCTRL {
                self.channels[channel_index].refresh_rx_status();
            }
        }
        // WR0 selection is one-shot for registers 1..15.
        self.channels[channel_index].selected = 0;
    }

    fn write_data(&mut self, channel_index: usize, value: u8) {
        let channel = &mut self.channels[channel_index];
        channel.tx_irq = false;
        if channel.write[W_TXCTRL2] & TX_ENABLE != 0 {
            if channel.write[W_MISC2] & MISC2_LOCAL_LOOP != 0 {
                channel.rx.push_back(value);
                channel.refresh_rx_status();
            } else {
                self.output.push(value);
            }
        }
        channel.read[R_STATUS] |= STATUS_TX_EMPTY;
        channel.read[R_SPEC] |= SPEC_ALL_SENT;
        channel.tx_irq = true;
    }

    pub fn inject_a(&mut self, byte: u8) {
        self.channels[1].rx.push_back(byte);
        self.channels[1].refresh_rx_status();
    }

    pub fn inject_b(&mut self, byte: u8) {
        self.channels[0].rx.push_back(byte);
        self.channels[0].refresh_rx_status();
    }

    pub fn take_output(&mut self) -> Vec<u8> {
        std::mem::take(&mut self.output)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn register_selection_and_tx_output_follow_sun_wiring() {
        let mut scc = Scc::default();
        // Channel A control is +4. Select WR5 and enable transmitter.
        scc.write(4, 5);
        scc.write(4, TX_ENABLE | 0x60);
        // Channel A data is +6.
        scc.write(6, b'>');
        assert_eq!(scc.take_output(), b">");
        assert_ne!(scc.read(4) & STATUS_TX_EMPTY, 0);
    }

    #[test]
    fn receive_queue_sets_and_clears_available_status() {
        let mut scc = Scc::default();
        scc.inject_a(b'x');
        assert_ne!(scc.read(4) & STATUS_RX_AVAILABLE, 0);
        assert_eq!(scc.read(6), b'x');
        assert_eq!(scc.read(4) & STATUS_RX_AVAILABLE, 0);
    }
}
