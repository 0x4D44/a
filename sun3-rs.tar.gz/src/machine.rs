//! Top-level deterministic Sun 3/60 machine scheduler.

use crate::bus::Sun3Bus;
use crate::trace::TraceFlags;
use m68k::{CpuCore, CpuType, NoOpHleHandler, StepResult};
use std::collections::BTreeSet;

/// Runtime configuration for a Sun 3/60 instance.
#[derive(Debug, Clone)]
pub struct MachineConfig {
    /// Installed physical RAM in bytes.
    pub ram_bytes: usize,
    /// Runtime trace selectors.
    pub trace_flags: TraceFlags,
    /// Number of recent trace records retained for failure diagnosis.
    pub trace_capacity: usize,
    /// Optional virtual-address breakpoints.
    pub breakpoints: BTreeSet<u32>,
}

impl Default for MachineConfig {
    fn default() -> Self {
        Self {
            ram_bytes: 24 * 1024 * 1024,
            trace_flags: TraceFlags::default(),
            trace_capacity: 4096,
            breakpoints: BTreeSet::new(),
        }
    }
}

/// Result from a bounded headless PROM run.
#[derive(Debug, Clone)]
pub struct RunOutcome {
    /// Whether an authentic monitor prompt was observed and answered with a
    /// carriage return, producing a second prompt.
    pub interactive_monitor: bool,
    /// Number of complete instructions retired.
    pub instructions: u64,
    /// Guest CPU cycles advanced.
    pub cycles: u64,
    /// Complete bytes emitted by the emulated serial console.
    pub transcript: Vec<u8>,
    /// Last virtual PC reached.
    pub pc: u32,
    /// A diagnostic explaining a non-successful bounded exit.
    pub diagnostic: Option<String>,
}

/// A complete single-CPU Sun 3/60 machine.
#[derive(Debug)]
pub struct Sun3Machine {
    /// MC68020 architectural state.
    pub cpu: CpuCore,
    /// Sun MMU, memory, and devices.
    pub bus: Sun3Bus,
    breakpoints: BTreeSet<u32>,
    instructions: u64,
    handler: NoOpHleHandler,
}

impl Sun3Machine {
    /// Construct and reset a Sun 3/60 using an unmodified 64 KiB PROM image.
    pub fn new(prom: Vec<u8>, config: MachineConfig) -> Result<Self, String> {
        let mut bus = Sun3Bus::new(
            config.ram_bytes,
            prom,
            config.trace_flags,
            config.trace_capacity,
        )?;
        let mut cpu = CpuCore::new();
        cpu.set_cpu_type(CpuType::M68020);
        cpu.fpu_present = true;
        bus.update_cpu_shadow(cpu.sfc, cpu.dfc, cpu.s_flag != 0);
        cpu.reset(&mut bus);
        bus.finish_reset_vectors();
        bus.update_cpu_shadow(cpu.sfc, cpu.dfc, cpu.s_flag != 0);
        cpu.set_irq(bus.interrupt_level());

        if config.trace_flags.prom {
            bus.trace.push(format!(
                "PROM RESET ssp={:08x} pc={:08x}",
                cpu.dar[15], cpu.pc
            ));
        }

        Ok(Self {
            cpu,
            bus,
            breakpoints: config.breakpoints,
            instructions: 0,
            handler: NoOpHleHandler,
        })
    }

    /// Number of retired instructions.
    pub fn instructions(&self) -> u64 {
        self.instructions
    }

    /// Inject bytes at serial port A, the PROM console selected by the supplied
    /// EEPROM image.
    pub fn inject_console(&mut self, bytes: &[u8]) {
        self.bus.inject_console(bytes);
    }

    /// Drain bytes emitted by the serial console since the last call.
    pub fn take_console_output(&mut self) -> Vec<u8> {
        self.bus.take_console_output()
    }

    /// Execute one architectural instruction boundary and advance devices.
    pub fn step(&mut self) -> Result<u64, String> {
        if self.breakpoints.contains(&self.cpu.pc) {
            return Err(format!("breakpoint reached at {:08x}", self.cpu.pc));
        }

        let pc_before = self.cpu.pc;
        let dar_before = if self.bus.trace_flags.cpu {
            Some(self.cpu.dar)
        } else {
            None
        };
        let sr_before = self.cpu.get_sr();

        let result = self
            .cpu
            .step_with_hle_handler(&mut self.bus, &mut self.handler);
        let cycles = match result {
            StepResult::Ok { cycles } => u64::try_from(cycles.max(0)).unwrap_or(0),
            StepResult::Stopped => {
                // A stopped 68020 still sees virtual time and can be awakened by
                // an interrupt. Advance one short scheduling quantum.
                256
            }
            other => {
                return Err(format!(
                    "unexpected surfaced CPU event {other:?} at {:08x}",
                    pc_before
                ));
            }
        };

        self.bus.advance(cycles);
        self.cpu.set_irq(self.bus.interrupt_level());
        self.bus
            .update_cpu_shadow(self.cpu.sfc, self.cpu.dfc, self.cpu.s_flag != 0);

        if !matches!(result, StepResult::Stopped) {
            self.instructions = self.instructions.saturating_add(1);
        }

        if self.bus.trace_flags.cpu {
            let mut deltas = Vec::new();
            if let Some(before) = dar_before {
                for (index, (old, new)) in before.into_iter().zip(self.cpu.dar).enumerate() {
                    if old != new {
                        let name = if index < 8 {
                            format!("d{index}")
                        } else {
                            format!("a{}", index - 8)
                        };
                        deltas.push(format!("{name}:{old:08x}->{new:08x}"));
                    }
                }
            }
            let sr_after = self.cpu.get_sr();
            if sr_before != sr_after {
                deltas.push(format!("sr:{sr_before:04x}->{sr_after:04x}"));
            }
            self.bus.trace.push(format!(
                "CPU pc={pc_before:08x} op={:04x} -> {:08x} cycles={} {}",
                self.bus.current_opcode(),
                self.cpu.pc,
                cycles,
                deltas.join(" ")
            ));
        }

        Ok(cycles)
    }

    /// Run the genuine PROM until an interactive monitor is demonstrated or
    /// the instruction budget is exhausted.
    ///
    /// The first `>` prompt is answered with a carriage return. Success is
    /// declared only after the PROM itself emits another `>` prompt.
    pub fn run_until_interactive_monitor(&mut self, max_instructions: u64) -> RunOutcome {
        let mut transcript = Vec::new();
        let mut first_prompt_at = None;
        let mut injected_probe = false;
        let mut diagnostic = None;

        while self.instructions < max_instructions {
            if let Err(error) = self.step() {
                diagnostic = Some(error);
                break;
            }

            let output = self.take_console_output();
            if !output.is_empty() {
                transcript.extend_from_slice(&output);

                let prompt_positions = transcript
                    .iter()
                    .enumerate()
                    .filter_map(|(index, byte)| (*byte == b'>').then_some(index))
                    .collect::<Vec<_>>();

                if first_prompt_at.is_none() {
                    first_prompt_at = prompt_positions.first().copied();
                }
                if first_prompt_at.is_some() && !injected_probe {
                    // An empty command exercises receive, SCC interrupt/status,
                    // firmware line editing, and command-loop return without
                    // relying on any hard-coded monitor command text.
                    self.inject_console(b"\r");
                    injected_probe = true;
                }
                if let Some(first) = first_prompt_at {
                    if prompt_positions.iter().any(|position| *position > first) {
                        return RunOutcome {
                            interactive_monitor: true,
                            instructions: self.instructions,
                            cycles: self.bus.cycles(),
                            transcript,
                            pc: self.cpu.pc,
                            diagnostic: None,
                        };
                    }
                }
            }
        }

        if diagnostic.is_none() {
            diagnostic = Some(format!(
                "instruction limit {max_instructions} reached at pc={:08x}",
                self.cpu.pc
            ));
        }
        RunOutcome {
            interactive_monitor: false,
            instructions: self.instructions,
            cycles: self.bus.cycles(),
            transcript,
            pc: self.cpu.pc,
            diagnostic,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reset_loads_vectors_from_prom_without_patching_cpu_state() {
        let mut prom = vec![0; 64 * 1024];
        prom[..8].copy_from_slice(&[
            0x00, 0x10, 0x00, 0x00, 0x0f, 0xef, 0x01, 0x00,
        ]);
        // NOP at PROM offset 0x100.
        prom[0x100..0x102].copy_from_slice(&[0x4e, 0x71]);
        let machine = Sun3Machine::new(prom, MachineConfig { ram_bytes: 4 << 20, ..Default::default() }).unwrap();
        assert_eq!(machine.cpu.dar[15], 0x0010_0000);
        assert_eq!(machine.cpu.pc, 0x0fef_0100);
    }
}
