//! Sun Microsystems Sun 3/60 machine emulation.
//!
//! The machine model is deterministic and executes an unmodified 68020 PROM.

pub mod bus;
pub mod devices;
pub mod machine;
pub mod mmu;
pub mod trace;

pub use machine::{MachineConfig, RunOutcome, Sun3Machine};
